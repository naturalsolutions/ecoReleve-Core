<?php
class XmlHelper extends AppHelper {

}
?>
