<?php
class JsonHelper extends AppHelper {

}
?>